package com.miloszjakubanis.thoughtseize.id.factory

import com.miloszjakubanis.thoughtseize.id.ID

trait IDFactory:
  def nextID: ID