package com.miloszjakubanis.thoughtseize.id

type ID = Long